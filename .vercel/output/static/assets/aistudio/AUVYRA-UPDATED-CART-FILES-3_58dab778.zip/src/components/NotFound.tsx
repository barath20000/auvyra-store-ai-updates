import { Link } from '@tanstack/react-router'
import { LogoMark } from './Logo'
import { useLanguage } from '@/lib/i18n'

export function NotFound() {
  const { t } = useLanguage()
  return (
    <section className="flex min-h-[70vh] items-center justify-center px-5 py-16">
      <div className="max-w-lg rounded-md border border-line bg-white p-10 text-center md:p-12">
        <LogoMark className="mx-auto mb-6 h-16 w-16 text-gold-light" />
        <h1 className="mb-4 font-serif text-[36px] font-normal leading-tight">
          {t('notFound.title')}
        </h1>
        <p className="mb-8 text-[14px] text-muted">{t('notFound.body')}</p>
        <div className="flex flex-wrap justify-center gap-3">
          <Link to="/" hash="store" className="btn btn-fill">
            {t('cart.browse')}
          </Link>
          <Link to="/" className="btn">
            {t('common.home')}
          </Link>
        </div>
      </div>
    </section>
  )
}
