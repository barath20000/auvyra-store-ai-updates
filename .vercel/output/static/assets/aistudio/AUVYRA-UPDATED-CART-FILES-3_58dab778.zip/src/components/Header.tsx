import { Link } from '@tanstack/react-router'
import { ShoppingBag } from 'lucide-react'
import { Logo } from './Logo'
import { useLanguage } from '@/lib/i18n'
import type { Lang } from '@/lib/i18n'
import { useStore } from '@/lib/store'

export function Header() {
  const { t, lang, setLang } = useLanguage()
  const { cartCount } = useStore()

  return (
    <header className="sticky top-0 z-20 border-b border-line bg-ivory/90 backdrop-blur-md">
      <div className="wrap flex min-h-[64px] items-center justify-between gap-3 md:min-h-[76px] md:gap-4">
        <Link to="/" aria-label="AUVYRA home">
          <Logo />
        </Link>

        <nav className="hidden gap-7 text-[13px] text-[#625b50] md:flex">
          <NavLinks />
        </nav>

        <div className="flex items-center gap-2.5">
          <div
            role="group"
            aria-label="Language"
            className="flex overflow-hidden rounded border border-line bg-white text-xs"
          >
            {(
              [
                ['en', 'EN'],
                ['ta', 'தமிழ்'],
              ] as Array<[Lang, string]>
            ).map(([code, label]) => (
              <button
                key={code}
                type="button"
                onClick={() => setLang(code)}
                aria-pressed={lang === code}
                className={`px-2.5 py-2 transition-colors ${
                  lang === code
                    ? 'bg-gold text-white'
                    : 'text-ink hover:text-gold'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <Link
            to="/cart"
            aria-label={`${t('nav.cart')} (${cartCount})`}
            className="relative flex h-[38px] w-[42px] items-center justify-center rounded border border-gold text-gold-deep transition-colors hover:bg-gold hover:text-white"
          >
            <ShoppingBag size={18} strokeWidth={1.6} />
            {cartCount > 0 && (
              <span className="absolute -right-2 -top-2 flex h-5 min-w-5 items-center justify-center rounded-full bg-gold px-1 text-[10px] font-medium text-white">
                {cartCount}
              </span>
            )}
          </Link>
        </div>
      </div>

      <nav className="wrap flex justify-center gap-8 border-t border-line py-2 text-[13px] text-[#625b50] md:hidden">
        <NavLinks />
      </nav>
    </header>
  )
}

function NavLinks() {
  const { t } = useLanguage()
  return (
    <>
      <Link to="/" hash="store" className="hover:text-gold">
        {t('nav.store')}
      </Link>
      <Link to="/" hash="about" className="hover:text-gold">
        {t('nav.about')}
      </Link>
      <Link to="/" hash="contact" className="hover:text-gold">
        {t('nav.contact')}
      </Link>
    </>
  )
}
