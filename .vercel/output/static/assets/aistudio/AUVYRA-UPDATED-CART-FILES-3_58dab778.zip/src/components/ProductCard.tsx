import { Link } from '@tanstack/react-router'
import { Check, Heart } from 'lucide-react'
import { BookCover } from './BookCover'
import { categories, formatPrice } from '@/data/products'
import type { Product } from '@/data/products'
import { useCatalogText, useLanguage } from '@/lib/i18n'
import { useStore } from '@/lib/store'

export function ProductCard({ product }: { product: Product }) {
  const { t } = useLanguage()
  const text = useCatalogText()
  const { inCart, addToCart, isSaved, toggleSaved } = useStore()
  const category = categories.find((c) => c.id === product.category)!
  const added = inCart(product.id)
  const saved = isSaved(product.id)

  return (
    <article className="group flex flex-col rounded-md border border-line bg-white p-4 transition duration-200 hover:-translate-y-0.5 hover:border-gold-light hover:shadow-[0_8px_22px_#80663814] sm:p-5">
      <Link
        to="/products/$productId"
        params={{ productId: String(product.id) }}
        className="mb-5 block bg-gradient-to-br from-cream to-ivory px-10 py-6 sm:px-12"
      >
        <BookCover
          product={product}
          className="mx-auto max-w-[170px] -rotate-2 transition-transform duration-300 group-hover:rotate-0"
        />
      </Link>

      <div className="text-[10px] uppercase tracking-[0.14em] text-gold">
        {text.category(category)} · {text.format(product.format)}
      </div>
      <h3 className="mt-1 font-serif text-2xl leading-tight">
        <Link
          to="/products/$productId"
          params={{ productId: String(product.id) }}
          className="hover:text-gold-deep"
        >
          {text.name(product)}
        </Link>
      </h3>
      <p className="mb-4 mt-1.5 text-[13px] text-muted">{text.short(product)}</p>

      <div className="mt-auto flex items-center justify-between gap-2 border-t border-line pt-4">
        <div>
          <div className="font-serif text-2xl text-ink">
            {formatPrice(product.price)}
          </div>
          <div className="text-[10px] text-[#9a9285]">
            {text.language(product.language)}
          </div>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => toggleSaved(product.id)}
            aria-pressed={saved}
            aria-label={saved ? t('card.saved') : t('card.save')}
            className={`flex h-10 w-10 items-center justify-center rounded border transition-colors ${
              saved
                ? 'border-gold-light bg-[#f8eee0] text-gold-deep'
                : 'border-line text-[#98763d] hover:border-gold-light'
            }`}
          >
            <Heart size={16} strokeWidth={1.6} fill={saved ? 'currentColor' : 'none'} />
          </button>
          <button
            type="button"
            onClick={() => addToCart(product.id)}
            disabled={added}
            className={`btn !px-3.5 !text-xs ${added ? '!cursor-default !opacity-100' : 'btn-fill'}`}
          >
            {added ? (
              <>
                <Check size={14} /> {t('card.added')}
              </>
            ) : (
              t('card.add')
            )}
          </button>
        </div>
      </div>
    </article>
  )
}
