import { LogoMark } from './Logo'
import { useLanguage } from '@/lib/i18n'
import { WHATSAPP_DISPLAY, whatsappLink } from '@/lib/site'

export function Footer() {
  const { t } = useLanguage()
  return (
    <footer className="border-t border-line py-8 text-[11px] text-[#8f887d]">
      <div className="wrap flex flex-wrap items-center justify-between gap-4">
        <span className="flex items-center gap-2 tracking-[0.2em] text-gold-deep">
          <LogoMark className="h-6 w-6 text-gold" />
          AUVYRA
        </span>
        <a href={whatsappLink()} target="_blank" rel="noopener" className="hover:text-gold">
          WhatsApp · {WHATSAPP_DISPLAY}
        </a>
        <span>
          © {new Date().getFullYear()} AUVYRA. {t('footer.rights')}
        </span>
      </div>
    </footer>
  )
}
