/** The BK open-book mark: Barath (left page) and Kavi (right page). */
export function LogoMark({ className = '' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      aria-hidden="true"
      className={className}
    >
      <path
        d="M7 15c10-4 18-2 25 5v33C24 46 16 44 7 48V15Z"
        stroke="currentColor"
        strokeWidth="2.4"
      />
      <path
        d="M57 15c-10-4-18-2-25 5v33c8-7 16-9 25-5V15Z"
        stroke="currentColor"
        strokeWidth="2.4"
      />
      <path d="M32 20v31" stroke="currentColor" strokeWidth="1.5" />
      <text x="13" y="37" fontSize="12" fontFamily="Georgia" fill="currentColor">
        B
      </text>
      <text x="39" y="37" fontSize="12" fontFamily="Georgia" fill="currentColor">
        K
      </text>
    </svg>
  )
}

export function Logo() {
  return (
    <span className="flex items-center gap-2.5">
      <LogoMark className="h-9 w-9 flex-none text-gold sm:h-11 sm:w-11" />
      <span className="leading-none">
        <span className="block font-serif text-[22px] font-medium sm:text-[26px] tracking-[0.18em] text-gold-deep">
          AUVYRA
        </span>
        <span className="mt-1 hidden text-[8px] sm:block tracking-[0.22em] text-[#8b8477]">
          KNOWLEDGE BEYOND LIMITS
        </span>
      </span>
    </span>
  )
}
