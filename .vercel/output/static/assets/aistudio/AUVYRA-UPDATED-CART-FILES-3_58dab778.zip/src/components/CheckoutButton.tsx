import { useEffect, useState } from 'react'
import { createCheckoutSession, getStripeEnabled } from '@/lib/stripe'
import { useLanguage } from '@/lib/i18n'
import products from '@/data/products'
import type { CartItem } from '@/lib/store'
import { WhatsAppOrderForm } from './WhatsAppOrderForm'

/** Starts checkout for the cart quantities, or opens the WhatsApp fallback. */
export function CheckoutButton({
  items,
  label,
  className = '',
}: {
  items: Array<Pick<CartItem, 'id' | 'quantity'>>
  label: string
  className?: string
}) {
  const { t } = useLanguage()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const [stripeEnabled, setStripeEnabled] = useState<boolean | null>(null)
  const [formOpen, setFormOpen] = useState(false)

  useEffect(() => {
    getStripeEnabled()
      .then(setStripeEnabled)
      .catch(() => setStripeEnabled(false))
  }, [])

  const handleClick = async () => {
    setLoading(true)
    setError(false)
    try {
      const url = await createCheckoutSession({ data: items })
      if (url) {
        window.location.href = url
        return
      }
      throw new Error('No checkout URL')
    } catch (err) {
      console.error('Checkout error:', err)
      setError(true)
      setLoading(false)
    }
  }

  if (stripeEnabled === false) {
    return (
      <div className={className}>
        <button
          type="button"
          onClick={() => setFormOpen(true)}
          disabled={items.length === 0}
          className="btn btn-fill w-full"
        >
          {t('checkout.whatsapp')}
        </button>
        <p className="mt-2 text-[11px] text-muted">
          {t('checkout.unavailableNote')}
        </p>
        <WhatsAppOrderForm
          items={products.filter((p) => items.some((item) => item.id === p.id)).map((p) => ({ ...p, quantity: items.find((item) => item.id === p.id)?.quantity ?? 1 }))}
          open={formOpen}
          onClose={() => setFormOpen(false)}
        />
      </div>
    )
  }

  return (
    <div className={className}>
      <button
        type="button"
        onClick={handleClick}
        disabled={loading || stripeEnabled === null || items.length === 0}
        className="btn btn-fill w-full"
      >
        {loading ? t('checkout.processing') : label}
      </button>
      {error && (
        <p role="alert" className="mt-2 text-[12px] text-[#a1452f]">
          {t('checkout.error')}
        </p>
      )}
    </div>
  )
}
