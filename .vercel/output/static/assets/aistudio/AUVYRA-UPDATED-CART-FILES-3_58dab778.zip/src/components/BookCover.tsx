import type { CategoryId, Product } from '@/data/products'

// Each category gets a subtle tint so covers are distinguishable but stay on-palette.
const tints: Record<CategoryId, { from: string; to: string; edge: string }> = {
  career: { from: '#fffaf0', to: '#f1e6cf', edge: '#c8a45e' },
  money: { from: '#fffdf6', to: '#ece3c8', edge: '#b9984f' },
  skills: { from: '#fdfbf6', to: '#e9e4d8', edge: '#a99161' },
  growth: { from: '#fffaf3', to: '#f3e3d2', edge: '#c39a63' },
}

/** A typographic book cover rendered in CSS — no image files needed. */
export function BookCover({
  product,
  size = 'md',
  className = '',
}: {
  product: Product
  size?: 'sm' | 'md' | 'lg'
  className?: string
}) {
  const tint = tints[product.category]
  const lg = size === 'lg'
  const sm = size === 'sm'
  return (
    <div
      className={`relative flex aspect-[3/4] flex-col justify-between border shadow-[10px_14px_28px_#80663822] ${
        lg ? 'p-8' : sm ? 'p-2' : 'p-4'
      } ${className}`}
      style={{
        background: `linear-gradient(145deg, ${tint.from}, ${tint.to})`,
        borderColor: tint.edge,
      }}
    >
      <span
        className="absolute bottom-0 top-0 border-l"
        style={{ left: lg ? 14 : sm ? 4 : 8, borderColor: `${tint.edge}66` }}
      />
      <span
        className={`tracking-[0.3em] text-[#9b7737] ${lg ? 'text-xs' : sm ? 'text-[5px]' : 'text-[8px]'}`}
      >
        AUVYRA
      </span>
      <span>
        <span
          className={`block font-serif leading-[1.05] text-[#5b4828] ${
            lg ? 'text-4xl md:text-5xl' : sm ? 'text-[10px]' : 'text-xl'
          }`}
        >
          {product.name}
        </span>
        <span
          className={`mt-2 block h-px bg-[#c8a45e] ${lg ? 'w-16' : sm ? 'hidden' : 'w-8'}`}
        />
      </span>
      <span
        className={`font-serif tracking-[0.2em] text-[#9b7737] ${lg ? 'text-base' : sm ? 'text-[5px]' : 'text-[10px]'}`}
      >
        {product.coverWord}
      </span>
    </div>
  )
}
