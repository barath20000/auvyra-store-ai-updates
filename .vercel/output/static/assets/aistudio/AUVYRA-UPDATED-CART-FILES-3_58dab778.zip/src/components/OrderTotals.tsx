import { formatPrice } from '@/data/products'
import { useLanguage } from '@/lib/i18n'
import { orderTotals } from '@/lib/pricing'

/** Product subtotal and final total, recalculated from catalog prices and quantities. */
export function OrderTotals({
  items,
  totalClassName = 'font-serif text-3xl',
}: {
  items: Array<{ price: number; quantity?: number }>
  totalClassName?: string
}) {
  const { t } = useLanguage()
  const { subtotal, total } = orderTotals(items)

  return (
    <div>
      <dl className="space-y-1.5 text-sm">
        <div className="flex items-baseline justify-between gap-3">
          <dt className="text-muted">{t('cart.productSubtotal')}</dt>
          <dd className="tabular-nums">{formatPrice(subtotal)}</dd>
        </div>
        <div className="flex items-baseline justify-between gap-3">
          <dt className="text-muted">{t('cart.digitalDelivery')}</dt>
          <dd className="font-medium text-gold-deep">{t('cart.included')}</dd>
        </div>
      </dl>
      <div className="mt-3 flex items-baseline justify-between gap-3 border-t border-line pt-3">
        <span className="eyebrow">{t('cart.finalTotal')}</span>
        <span className={`${totalClassName} tabular-nums`}>{formatPrice(total)}</span>
      </div>
    </div>
  )
}
