import { Link, createFileRoute } from '@tanstack/react-router'
import { useMemo, useState } from 'react'
import { Heart, Search } from 'lucide-react'
import products, { categories } from '@/data/products'
import type { CategoryId, Format } from '@/data/products'
import { BookCover } from '@/components/BookCover'
import { LogoMark } from '@/components/Logo'
import { ProductCard } from '@/components/ProductCard'
import { useCatalogText, useLanguage } from '@/lib/i18n'
import type { TKey } from '@/lib/i18n'
import { useStore } from '@/lib/store'
import { WHATSAPP_DISPLAY, whatsappLink } from '@/lib/site'

export const Route = createFileRoute('/')({
  component: Home,
})

function Home() {
  return (
    <>
      <Hero />
      <Promises />
      <Store />
      <About />
      <Contact />
    </>
  )
}

function Hero() {
  const { t } = useLanguage()
  const featured = products.filter((p) => p.featured)
  const [back, front] = [featured[0], featured[2] ?? featured[1]]

  return (
    <section className="border-b border-line bg-[linear-gradient(110deg,#fffdf8,#f8f2e5_70%,#fffdf8)] py-14 md:py-20">
      <div className="wrap grid items-center gap-10 md:grid-cols-[1.15fr_.85fr] md:gap-12">
        <div>
          <div className="eyebrow">{t('hero.eyebrow')}</div>
          <h1 className="my-5 font-serif text-[clamp(44px,6.5vw,78px)] font-normal leading-[1.02]">
            {t('hero.title')}
          </h1>
          <p className="mb-7 max-w-[520px] text-[15px] text-muted">
            {t('hero.body')}
          </p>
          <div className="flex flex-wrap gap-3">
            <Link to="/" hash="store" className="btn btn-fill">
              {t('hero.cta')}
            </Link>
            <Link to="/" hash="about" className="btn">
              {t('hero.story')}
            </Link>
          </div>
          <div className="mt-5 text-[10px] tracking-[0.12em] text-[#9a9285]">
            {t('hero.note')}
          </div>
        </div>

        <div className="relative mx-auto flex h-[280px] w-full max-w-[360px] items-center justify-center md:h-[340px]">
          <div className="absolute h-[250px] w-[250px] rounded-full border border-[#cbb27d88] shadow-[0_0_70px_#b18b3b18] md:h-[300px] md:w-[300px]" />
          <Link
            to="/products/$productId"
            params={{ productId: String(back.id) }}
            className="absolute left-[12%] top-[8%] w-[130px] rotate-[-10deg] opacity-90 transition-transform hover:rotate-[-6deg] md:w-[150px]"
          >
            <BookCover product={back} />
          </Link>
          <Link
            to="/products/$productId"
            params={{ productId: String(front.id) }}
            className="relative ml-16 mt-8 w-[150px] rotate-[4deg] transition-transform hover:rotate-0 md:w-[180px]"
          >
            <BookCover product={front} />
          </Link>
        </div>
      </div>
    </section>
  )
}

function Promises() {
  const { t } = useLanguage()
  const items: Array<[TKey, TKey]> = [
    ['promise.1t', 'promise.1b'],
    ['promise.2t', 'promise.2b'],
    ['promise.3t', 'promise.3b'],
    ['promise.4t', 'promise.4b'],
  ]
  return (
    <section className="border-b border-line bg-white">
      <div className="wrap grid grid-cols-2 gap-x-6 gap-y-5 py-7 md:grid-cols-4">
        {items.map(([title, body]) => (
          <div key={title} className="flex gap-3">
            <span className="mt-0.5 text-gold">✦</span>
            <div>
              <div className="font-serif text-lg leading-tight">{t(title)}</div>
              <div className="text-[11px] text-muted">{t(body)}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

function Store() {
  const { t } = useLanguage()
  const text = useCatalogText()
  const { wishlist } = useStore()
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState<CategoryId | 'all'>('all')
  const [format, setFormat] = useState<Format | 'all'>('all')
  const [onlySaved, setOnlySaved] = useState(false)

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase()
    return products.filter((p) => {
      const haystack = [p.name, p.nameTa, p.shortDescription, p.shortDescriptionTa, p.coverWord]
        .join(' ')
        .toLowerCase()
      return (
        (!q || haystack.includes(q)) &&
        (category === 'all' || p.category === category) &&
        (format === 'all' || p.format === format) &&
        (!onlySaved || wishlist.includes(p.id))
      )
    })
  }, [query, category, format, onlySaved, wishlist])

  const reset = () => {
    setQuery('')
    setCategory('all')
    setFormat('all')
    setOnlySaved(false)
  }

  return (
    <section id="store" className="scroll-mt-28 md:scroll-mt-20 py-14 md:py-16">
      <div className="wrap">
        <div className="mb-7 flex flex-col justify-between gap-3 md:flex-row md:items-end">
          <div>
            <div className="eyebrow">{t('store.eyebrow')}</div>
            <h2 className="mt-2 font-serif text-[34px] font-normal leading-tight md:text-[42px]">
              {t('store.title')}
            </h2>
          </div>
          <p className="max-w-[430px] text-[13px] text-muted">{t('store.intro')}</p>
        </div>

        <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
          {categories.map((c) => {
            const active = category === c.id
            const count = products.filter((p) => p.category === c.id).length
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => setCategory(active ? 'all' : c.id)}
                aria-pressed={active}
                className={`rounded-md border p-4 text-left transition-colors ${
                  active
                    ? 'border-gold bg-[#fbf5e8]'
                    : 'border-line bg-white hover:border-gold-light'
                }`}
              >
                <span className="block font-serif text-[19px] leading-tight md:text-[21px]">
                  {text.category(c)}
                </span>
                <span className="mt-1 block text-[11px] text-muted">
                  {text.categoryBlurb(c)}
                </span>
                <span className="mt-2 block text-[10px] tracking-[0.12em] text-gold">
                  {count} {t('store.items')}
                </span>
              </button>
            )
          })}
        </div>

        <div className="mb-6 flex flex-wrap gap-2.5">
          <label className="relative min-w-[200px] flex-1">
            <Search
              size={15}
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#a89f90]"
            />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t('store.search')}
              aria-label={t('store.search')}
              className="field w-full !pl-9"
            />
          </label>
          <select
            value={format}
            onChange={(e) => setFormat(e.target.value as Format | 'all')}
            aria-label={t('product.format')}
            className="field"
          >
            <option value="all">{t('store.allFormats')}</option>
            <option value="ebook">{text.format('ebook')}</option>
            <option value="template">{text.format('template')}</option>
            <option value="guide">{text.format('guide')}</option>
          </select>
          <button
            type="button"
            onClick={() => setOnlySaved((v) => !v)}
            aria-pressed={onlySaved}
            className={`field flex items-center gap-2 ${onlySaved ? '!border-gold-light !bg-[#f8eee0]' : ''}`}
          >
            <Heart size={15} strokeWidth={1.6} fill={onlySaved ? 'currentColor' : 'none'} className="text-gold-deep" />
            {t('store.wishlist')} ({wishlist.length})
          </button>
        </div>

        {visible.length > 0 ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {visible.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        ) : (
          <div className="rounded-md border border-dashed border-line bg-white py-14 text-center">
            <p className="mb-4 text-sm text-muted">{t('store.empty')}</p>
            <button type="button" onClick={reset} className="btn">
              {t('store.reset')}
            </button>
          </div>
        )}
      </div>
    </section>
  )
}

function About() {
  const { t } = useLanguage()
  return (
    <section id="about" className="scroll-mt-28 md:scroll-mt-20 border-y border-line bg-cream py-14 md:py-16">
      <div className="wrap grid items-center gap-8 md:grid-cols-[.8fr_1.2fr] md:gap-14">
        <div className="rounded-md border border-[#d7c49c] bg-ivory p-8 text-center">
          <LogoMark className="mx-auto mb-3 h-16 w-16 text-gold" />
          <strong className="block font-serif text-4xl font-medium tracking-[0.2em] text-[#9b7737]">
            AUVYRA
          </strong>
          <span className="mt-2 block text-[9px] tracking-[0.22em] text-[#92836a]">
            KNOWLEDGE BEYOND LIMITS
          </span>
          <span className="mt-5 block font-serif text-lg italic text-gold-deep">
            Barath &amp; Kavi
          </span>
        </div>
        <div>
          <div className="eyebrow">{t('about.eyebrow')}</div>
          <h2 className="mb-4 mt-2 font-serif text-[34px] font-normal leading-tight md:text-[42px]">
            {t('about.title')}
          </h2>
          <p className="text-[14px] text-muted">{t('about.body')}</p>
          <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-[12px] text-[#65563b]">
            {(['about.v1', 'about.v2', 'about.v3'] as const).map((k) => (
              <span key={k}>
                <span className="mr-2 text-gold">✦</span>
                {t(k)}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function Contact() {
  const { t } = useLanguage()
  return (
    <section id="contact" className="scroll-mt-28 md:scroll-mt-20 bg-[#fffaf0] py-14 text-center">
      <div className="wrap">
        <div className="eyebrow">{t('contact.eyebrow')}</div>
        <h2 className="my-3 font-serif text-[32px] font-normal leading-tight md:text-[38px]">
          {t('contact.title')}
        </h2>
        <p className="mx-auto mb-6 max-w-md text-[13px] text-muted">{t('contact.body')}</p>
        <a href={whatsappLink()} target="_blank" rel="noopener" className="btn btn-fill">
          WhatsApp AUVYRA · {WHATSAPP_DISPLAY}
        </a>
      </div>
    </section>
  )
}
