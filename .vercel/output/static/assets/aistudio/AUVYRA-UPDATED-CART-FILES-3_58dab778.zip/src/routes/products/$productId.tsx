import { Link, createFileRoute, notFound } from '@tanstack/react-router'
import { ArrowLeft, Check, Heart, ShieldCheck } from 'lucide-react'
import products, { categories, formatPrice, getProduct } from '@/data/products'
import { BookCover } from '@/components/BookCover'
import { CheckoutButton } from '@/components/CheckoutButton'
import { ProductCard } from '@/components/ProductCard'
import { useCatalogText, useLanguage } from '@/lib/i18n'
import { useStore } from '@/lib/store'

export const Route = createFileRoute('/products/$productId')({
  component: ProductPage,
  notFoundComponent: ProductNotFound,
  loader: ({ params }) => {
    const product = getProduct(Number(params.productId))
    if (!product) throw notFound()
    return product
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.name} — AUVYRA` },
          { name: 'description', content: loaderData.shortDescription },
        ]
      : [],
  }),
})

function ProductPage() {
  const product = Route.useLoaderData()
  const { t } = useLanguage()
  const text = useCatalogText()
  const { inCart, addToCart, isSaved, toggleSaved } = useStore()
  const category = categories.find((c) => c.id === product.category)!
  const related = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .concat(products.filter((p) => p.category !== product.category && p.featured))
    .slice(0, 3)
  const added = inCart(product.id)
  const saved = isSaved(product.id)

  const specs: Array<[string, string]> = [
    [t('product.format'), text.format(product.format)],
    [t('product.language'), text.language(product.language)],
    [t('product.length'), `${product.pages} ${t('card.pages')}`],
    [t('product.delivery'), t('product.deliveryValue')],
  ]

  return (
    <>
      <section className="border-b border-line bg-[linear-gradient(110deg,#fffdf8,#f8f2e5_70%,#fffdf8)] py-10 md:py-16">
        <div className="wrap">
          <Link
            to="/"
            hash="store"
            className="mb-8 inline-flex items-center gap-2 text-[13px] text-muted hover:text-gold"
          >
            <ArrowLeft size={14} /> {t('product.back')}
          </Link>

          <div className="grid items-start gap-10 md:grid-cols-[.9fr_1.1fr] md:gap-16">
            <div className="flex justify-center bg-gradient-to-br from-cream to-ivory px-8 py-10 md:py-14">
              <BookCover product={product} size="lg" className="w-full max-w-[300px] -rotate-2" />
            </div>

            <div>
              <div className="eyebrow">
                {text.category(category)} · {text.format(product.format)}
              </div>
              <h1 className="mb-4 mt-3 font-serif text-[40px] font-normal leading-[1.05] md:text-[56px]">
                {text.name(product)}
              </h1>
              <p className="mb-6 text-[15px] text-muted">{text.description(product)}</p>

              <div className="mb-6 font-serif text-4xl">{formatPrice(product.price)}</div>

              <div className="mb-3 grid gap-2.5 sm:grid-cols-[1fr_1fr_auto]">
                <CheckoutButton
                  items={[{ id: product.id, quantity: 1 }]}
                  label={t('product.buy')}
                />
                <button
                  type="button"
                  onClick={() => addToCart(product.id)}
                  disabled={added}
                  className="btn h-fit disabled:!opacity-100"
                >
                  {added ? (
                    <>
                      <Check size={14} /> {t('card.added')}
                    </>
                  ) : (
                    t('card.add')
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => toggleSaved(product.id)}
                  aria-pressed={saved}
                  className={`btn h-fit ${saved ? '!bg-[#f8eee0] !text-gold-deep' : ''}`}
                >
                  <Heart size={15} fill={saved ? 'currentColor' : 'none'} />
                  <span className="sm:sr-only">{saved ? t('card.saved') : t('card.save')}</span>
                </button>
              </div>
              <p className="mb-8 flex items-center gap-1.5 text-[11px] text-[#9a9285]">
                <ShieldCheck size={13} /> {t('product.secure')}
              </p>

              <dl className="mb-8 grid grid-cols-2 border-y border-line">
                {specs.map(([label, value]) => (
                  <div key={label} className="border-b border-line py-3 pr-3 last:border-b-0 [&:nth-last-child(2)]:border-b-0">
                    <dt className="text-[10px] uppercase tracking-[0.14em] text-gold">{label}</dt>
                    <dd className="mt-0.5 text-[13px]">{value}</dd>
                  </div>
                ))}
              </dl>

              <h2 className="mb-3 font-serif text-2xl">{t('product.includes')}</h2>
              <ul className="space-y-2 text-[14px] text-[#5d5649]">
                {text.includes(product).map((item) => (
                  <li key={item} className="flex gap-3">
                    <span className="text-gold">✦</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="py-14">
        <div className="wrap">
          <h2 className="mb-6 font-serif text-[32px] font-normal">{t('product.related')}</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>
    </>
  )
}

function ProductNotFound() {
  const { t } = useLanguage()
  return (
    <div className="wrap py-24 text-center">
      <h1 className="mb-4 font-serif text-4xl">{t('notFound.title')}</h1>
      <Link to="/" hash="store" className="btn">
        {t('product.back')}
      </Link>
    </div>
  )
}
