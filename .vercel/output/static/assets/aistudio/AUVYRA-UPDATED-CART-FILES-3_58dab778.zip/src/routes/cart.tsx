import { Link, createFileRoute } from '@tanstack/react-router'
import { Minus, Plus, X } from 'lucide-react'
import { categories, formatPrice } from '@/data/products'
import { BookCover } from '@/components/BookCover'
import { CheckoutButton } from '@/components/CheckoutButton'
import { OrderTotals } from '@/components/OrderTotals'
import { useCatalogText, useLanguage } from '@/lib/i18n'
import { useStore } from '@/lib/store'
import { orderTotals } from '@/lib/pricing'

export const Route = createFileRoute('/cart')({
  component: CartPage,
  head: () => ({ meta: [{ title: 'Your cart — AUVYRA' }] }),
})

function CartPage() {
  const { t } = useLanguage()
  const text = useCatalogText()
  const { cartItems, increaseQuantity, decreaseQuantity, removeFromCart } = useStore()
  const { total } = orderTotals(cartItems)

  return (
    <section className="min-h-[60vh] py-12 md:py-16">
      <div className="wrap">
        <h1 className="mb-8 font-serif text-[40px] font-normal md:text-[48px]">
          {t('cart.title')}
        </h1>

        {cartItems.length === 0 ? (
          <div className="rounded-md border border-dashed border-line bg-white py-16 text-center">
            <p className="mb-5 text-sm text-muted">{t('cart.empty')}</p>
            <Link to="/" hash="store" className="btn btn-fill">
              {t('cart.browse')}
            </Link>
          </div>
        ) : (
          <div className="grid items-start gap-8 lg:grid-cols-[1fr_340px]">
            <ul className="divide-y divide-line rounded-md border border-line bg-white">
              {cartItems.map((p) => {
                const category = categories.find((c) => c.id === p.category)!
                return (
                  <li key={p.id} className="flex items-center gap-4 p-4 sm:gap-5 sm:p-5">
                    <Link
                      to="/products/$productId"
                      params={{ productId: String(p.id) }}
                      className="w-16 flex-none sm:w-20"
                    >
                      <BookCover product={p} size="sm" />
                    </Link>
                    <div className="min-w-0 flex-1">
                      <div className="text-[10px] uppercase tracking-[0.14em] text-gold">
                        {text.category(category)} · {text.format(p.format)}
                      </div>
                      <Link
                        to="/products/$productId"
                        params={{ productId: String(p.id) }}
                        className="block font-serif text-xl leading-tight hover:text-gold-deep"
                      >
                        {text.name(p)}
                      </Link>
                      <div className="text-[11px] text-[#9a9285]">{text.language(p.language)}</div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <div className="font-serif text-xl">{formatPrice(p.price * p.quantity)}</div>
                      <div className="inline-flex items-center rounded border border-line bg-cream" aria-label={`Quantity for ${text.name(p)}`}>
                        <button type="button" onClick={() => decreaseQuantity(p.id)} disabled={p.quantity <= 1} aria-label={`Decrease ${text.name(p)} quantity`} className="p-2 text-muted transition hover:text-ink disabled:cursor-not-allowed disabled:opacity-30">
                          <Minus size={14} />
                        </button>
                        <span aria-live="polite" className="min-w-8 text-center text-sm tabular-nums">{p.quantity}</span>
                        <button type="button" onClick={() => increaseQuantity(p.id)} disabled={p.quantity >= 99} aria-label={`Increase ${text.name(p)} quantity`} className="p-2 text-muted transition hover:text-ink disabled:cursor-not-allowed disabled:opacity-30">
                          <Plus size={14} />
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFromCart(p.id)}
                        className="mt-1 inline-flex items-center gap-1 text-[11px] text-muted hover:text-[#a1452f]"
                      >
                        <X size={12} /> {t('cart.remove')}
                      </button>
                    </div>
                  </li>
                )
              })}
            </ul>

            <aside className="rounded-md border border-line bg-cream p-6 lg:sticky lg:top-24">
              <OrderTotals items={cartItems} />
              <p className="mb-5 mt-1 text-[11px] text-muted">{t('cart.note')}</p>
              <CheckoutButton
                items={cartItems.map((p) => ({ id: p.id, quantity: p.quantity }))}
                label={`${t('cart.checkout')} · ${formatPrice(total)}`}
              />
              <p className="mt-4 text-center text-[11px] text-[#9a9285]">
                {t('product.secure')}
              </p>
            </aside>
          </div>
        )}
      </div>
    </section>
  )
}
