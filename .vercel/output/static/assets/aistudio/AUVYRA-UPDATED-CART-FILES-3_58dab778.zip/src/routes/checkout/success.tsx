import { Link, createFileRoute } from '@tanstack/react-router'
import { useEffect } from 'react'
import { LogoMark } from '@/components/Logo'
import { useLanguage } from '@/lib/i18n'
import { useStore } from '@/lib/store'
import { WHATSAPP_DISPLAY, whatsappLink } from '@/lib/site'

export const Route = createFileRoute('/checkout/success')({
  component: CheckoutSuccess,
  head: () => ({ meta: [{ title: 'Thank you — AUVYRA' }] }),
})

function CheckoutSuccess() {
  const { t } = useLanguage()
  const { clearCart } = useStore()

  useEffect(() => {
    clearCart()
  }, [])

  return (
    <section className="flex min-h-[70vh] items-center justify-center px-5 py-16">
      <div className="max-w-lg rounded-md border border-[#d7c49c] bg-white p-10 text-center md:p-12">
        <LogoMark className="mx-auto mb-6 h-16 w-16 text-gold" />
        <h1 className="mb-4 font-serif text-[36px] font-normal leading-tight">
          {t('success.title')}
        </h1>
        <p className="mb-8 text-[14px] text-muted">{t('success.body')}</p>
        <div className="flex flex-wrap justify-center gap-3">
          <Link to="/" className="btn btn-fill">
            {t('common.home')}
          </Link>
          <a href={whatsappLink()} target="_blank" rel="noopener" className="btn">
            WhatsApp · {WHATSAPP_DISPLAY}
          </a>
        </div>
      </div>
    </section>
  )
}
