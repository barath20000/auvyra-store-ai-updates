/** AUVYRA sells digital products, so checkout has no physical delivery fee. */
export const FREE_DELIVERY_THRESHOLD = 0
export const DELIVERY_FEE = 0

export function deliveryFee(_subtotal: number) {
  return 0
}

/** Subtotal and final total are calculated from server/catalog prices and quantities. */
export function orderTotals(items: Array<{ price: number; quantity?: number }>) {
  const subtotal = items.reduce((sum, p) => sum + p.price * (p.quantity ?? 1), 0)
  const delivery = 0
  return { subtotal, delivery, total: subtotal }
}
