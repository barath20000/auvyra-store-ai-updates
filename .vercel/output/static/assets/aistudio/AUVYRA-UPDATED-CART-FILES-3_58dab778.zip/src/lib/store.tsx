import { createContext, useContext, useEffect, useState } from 'react'
import products from '@/data/products'
import type { Product } from '@/data/products'

export type CartItem = Product & { quantity: number }

interface StoreContextValue {
  cart: Array<number>
  wishlist: Array<number>
  cartItems: Array<CartItem>
  cartCount: number
  subtotal: number
  inCart: (id: number) => boolean
  addToCart: (id: number) => void
  increaseQuantity: (id: number) => void
  decreaseQuantity: (id: number) => void
  removeFromCart: (id: number) => void
  clearCart: () => void
  isSaved: (id: number) => boolean
  toggleSaved: (id: number) => void
}

const StoreContext = createContext<StoreContextValue | null>(null)
const CART_KEY = 'auvyra:cart'
const WISH_KEY = 'auvyra:wishlist'
const MAX_QUANTITY = 99

type SavedCart = { id: number; quantity: number }

function readCart(): { ids: number[]; quantities: Record<number, number> } {
  try {
    const raw: unknown = JSON.parse(window.localStorage.getItem(CART_KEY) ?? '[]')
    // Migrate the previous format (an array of product IDs) without losing carts.
    const entries: SavedCart[] = Array.isArray(raw)
      ? raw.map((id) => ({ id, quantity: 1 }))
      : raw && typeof raw === 'object' && 'items' in raw && Array.isArray(raw.items)
        ? raw.items
        : []
    const quantities: Record<number, number> = {}
    for (const entry of entries) {
      if (!entry || !products.some((p) => p.id === entry.id)) continue
      const quantity = Number.isFinite(entry.quantity)
        ? Math.min(MAX_QUANTITY, Math.max(1, Math.floor(entry.quantity)))
        : 1
      quantities[entry.id] = quantity
    }
    return { ids: products.filter((p) => quantities[p.id]).map((p) => p.id), quantities }
  } catch {
    return { ids: [], quantities: {} }
  }
}

function readIds(key: string): Array<number> {
  try {
    const raw = JSON.parse(window.localStorage.getItem(key) ?? '[]')
    return Array.isArray(raw)
      ? raw.filter((id) => products.some((p) => p.id === id))
      : []
  } catch {
    return []
  }
}

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = useState<Array<number>>([])
  const [quantities, setQuantities] = useState<Record<number, number>>({})
  const [wishlist, setWishlist] = useState<Array<number>>([])
  const [hydrated, setHydrated] = useState(false)

  useEffect(() => {
    const savedCart = readCart()
    setCart(savedCart.ids)
    setQuantities(savedCart.quantities)
    setWishlist(readIds(WISH_KEY))
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (hydrated) {
      window.localStorage.setItem(
        CART_KEY,
        JSON.stringify({ items: cart.map((id) => ({ id, quantity: quantities[id] ?? 1 })) }),
      )
    }
  }, [cart, quantities, hydrated])

  useEffect(() => {
    if (hydrated) window.localStorage.setItem(WISH_KEY, JSON.stringify(wishlist))
  }, [wishlist, hydrated])

  const cartItems: CartItem[] = products
    .filter((p) => cart.includes(p.id))
    .map((p) => ({ ...p, quantity: quantities[p.id] ?? 1 }))
  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0)
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)

  const value: StoreContextValue = {
    cart,
    wishlist,
    cartItems,
    cartCount,
    subtotal,
    inCart: (id) => cart.includes(id),
    addToCart: (id) => {
      if (!products.some((p) => p.id === id)) return
      setCart((current) => current.includes(id) ? current : [...current, id])
      setQuantities((current) => ({
        ...current,
        [id]: Math.min(MAX_QUANTITY, (current[id] ?? 0) + 1),
      }))
    },
    increaseQuantity: (id) => setQuantities((current) =>
      cart.includes(id)
        ? { ...current, [id]: Math.min(MAX_QUANTITY, (current[id] ?? 1) + 1) }
        : current,
    ),
    decreaseQuantity: (id) => setQuantities((current) =>
      cart.includes(id) && (current[id] ?? 1) > 1
        ? { ...current, [id]: current[id] - 1 }
        : current,
    ),
    removeFromCart: (id) => {
      setCart((current) => current.filter((x) => x !== id))
      setQuantities((current) => {
        const next = { ...current }
        delete next[id]
        return next
      })
    },
    clearCart: () => {
      window.localStorage.setItem(CART_KEY, JSON.stringify({ items: [] }))
      setCart([])
      setQuantities({})
    },
    isSaved: (id) => wishlist.includes(id),
    toggleSaved: (id) => setWishlist((w) =>
      w.includes(id) ? w.filter((x) => x !== id) : [...w, id],
    ),
  }

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export function useStore() {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error('useStore must be used inside StoreProvider')
  return ctx
}
