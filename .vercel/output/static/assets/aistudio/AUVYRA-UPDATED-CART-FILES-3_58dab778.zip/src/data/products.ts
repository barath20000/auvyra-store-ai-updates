export type CategoryId = 'career' | 'money' | 'skills' | 'growth'
export type Format = 'ebook' | 'template' | 'guide'
export type BookLanguage = 'en' | 'ta' | 'both'

export interface Category {
  id: CategoryId
  name: string
  nameTa: string
  blurb: string
  blurbTa: string
}

export const categories: Array<Category> = [
  {
    id: 'career',
    name: 'Education & Career',
    nameTa: 'கல்வி & தொழில்',
    blurb: 'Study, jobs and professional growth',
    blurbTa: 'படிப்பு, வேலை மற்றும் தொழில் வளர்ச்சி',
  },
  {
    id: 'money',
    name: 'Money & Business',
    nameTa: 'பணம் & வணிகம்',
    blurb: 'Budgeting and business basics',
    blurbTa: 'பட்ஜெட் மற்றும் வணிக அடிப்படைகள்',
  },
  {
    id: 'skills',
    name: 'Technology & Skills',
    nameTa: 'தொழில்நுட்பம் & திறன்கள்',
    blurb: 'Digital tools and practical skills',
    blurbTa: 'டிஜிட்டல் கருவிகள் மற்றும் நடைமுறைத் திறன்கள்',
  },
  {
    id: 'growth',
    name: 'Lifestyle & Personal Growth',
    nameTa: 'வாழ்க்கை முறை & தனிப்பட்ட வளர்ச்சி',
    blurb: 'Habits and personal development',
    blurbTa: 'பழக்கங்கள் மற்றும் தனிப்பட்ட முன்னேற்றம்',
  },
]

export interface Product {
  id: number
  slug: string
  category: CategoryId
  format: Format
  language: BookLanguage
  coverWord: string
  name: string
  nameTa: string
  shortDescription: string
  shortDescriptionTa: string
  description: string
  descriptionTa: string
  includes: Array<string>
  includesTa: Array<string>
  pages: number
  /** Price in Indian rupees (whole rupees). Server-side source of truth for checkout. */
  price: number
  featured?: boolean
}

const products: Array<Product> = [
  {
    id: 1,
    slug: 'resume-starter-kit',
    category: 'career',
    format: 'template',
    language: 'both',
    coverWord: 'CAREER',
    name: 'Resume Starter Kit',
    nameTa: 'ரெஸ்யூம் தொடக்கக் கருவி',
    shortDescription:
      'Simple resume layouts and a checklist for first-time job seekers.',
    shortDescriptionTa:
      'முதல் முறை வேலை தேடுபவர்களுக்கான எளிய ரெஸ்யூம் வடிவங்கள் மற்றும் சரிபார்ப்புப் பட்டியல்.',
    description:
      'Five clean, recruiter-friendly resume layouts you can edit in Word or Google Docs, plus a step-by-step checklist that walks you through writing a strong summary, listing projects and tailoring your resume to each job.',
    descriptionTa:
      'Word அல்லது Google Docs-இல் திருத்தக்கூடிய ஐந்து தெளிவான ரெஸ்யூம் வடிவங்கள். வலுவான சுருக்கம் எழுதுவது, திட்டங்களைப் பட்டியலிடுவது மற்றும் ஒவ்வொரு வேலைக்கும் ஏற்ப மாற்றுவது பற்றிய படிப்படியான வழிகாட்டியும் உள்ளது.',
    includes: ['5 editable resume layouts', 'Cover letter sample', 'Job-ready checklist'],
    includesTa: ['5 திருத்தக்கூடிய ரெஸ்யூம் வடிவங்கள்', 'கவர் லெட்டர் மாதிரி', 'வேலைக்குத் தயார் சரிபார்ப்புப் பட்டியல்'],
    pages: 24,
    price: 199,
    featured: true,
  },
  {
    id: 2,
    slug: 'interview-ready',
    category: 'career',
    format: 'guide',
    language: 'both',
    coverWord: 'INTERVIEW',
    name: 'Interview Ready',
    nameTa: 'நேர்காணலுக்குத் தயார்',
    shortDescription:
      'Common interview questions with clear sample answers in Tamil and English.',
    shortDescriptionTa:
      'பொதுவான நேர்காணல் கேள்விகளும் தெளிவான மாதிரி பதில்களும் — தமிழிலும் ஆங்கிலத்திலும்.',
    description:
      'Walk into your next interview with confidence. This guide covers the 50 most common questions, how to structure your answers, body language basics and a simple preparation plan for the week before.',
    descriptionTa:
      'அடுத்த நேர்காணலுக்கு நம்பிக்கையுடன் செல்லுங்கள். அதிகம் கேட்கப்படும் 50 கேள்விகள், பதில்களை அமைக்கும் முறை, உடல்மொழி அடிப்படைகள் மற்றும் ஒரு வார தயாரிப்புத் திட்டம் இதில் உள்ளன.',
    includes: ['50 questions with sample answers', 'One-week prep plan', 'HR round tips'],
    includesTa: ['மாதிரி பதில்களுடன் 50 கேள்விகள்', 'ஒரு வார தயாரிப்புத் திட்டம்', 'HR சுற்றுக்கான குறிப்புகள்'],
    pages: 68,
    price: 249,
  },
  {
    id: 3,
    slug: 'everyday-money-basics',
    category: 'money',
    format: 'ebook',
    language: 'ta',
    coverWord: 'MONEY',
    name: 'Everyday Money Basics',
    nameTa: 'அன்றாட பண அடிப்படைகள்',
    shortDescription:
      'A simple guide to budgeting, tracking expenses and building better money habits.',
    shortDescriptionTa:
      'பட்ஜெட், செலவுக் கண்காணிப்பு மற்றும் சிறந்த பணப் பழக்கங்களுக்கான எளிய வழிகாட்டி.',
    description:
      'Money made simple. Learn how to build a monthly budget, set up an emergency fund, understand savings options and avoid common debt traps — explained in plain, friendly language.',
    descriptionTa:
      'எளிமையாக்கப்பட்ட பண மேலாண்மை. மாதாந்திர பட்ஜெட் அமைப்பது, அவசர நிதி சேமிப்பது, சேமிப்பு வழிகளைப் புரிந்துகொள்வது மற்றும் கடன் சிக்கல்களைத் தவிர்ப்பது — எளிய மொழியில்.',
    includes: ['Monthly budget worksheet', '30-day savings challenge', 'Expense tracker'],
    includesTa: ['மாதாந்திர பட்ஜெட் தாள்', '30 நாள் சேமிப்புச் சவால்', 'செலவுக் கண்காணிப்பு'],
    pages: 82,
    price: 179,
    featured: true,
  },
  {
    id: 4,
    slug: 'small-business-starter',
    category: 'money',
    format: 'template',
    language: 'en',
    coverWord: 'BUSINESS',
    name: 'Small Business Starter Pack',
    nameTa: 'சிறு வணிகத் தொடக்கத் தொகுப்பு',
    shortDescription:
      'Invoice, pricing and planning templates for your first small business.',
    shortDescriptionTa:
      'உங்கள் முதல் சிறு வணிகத்திற்கான விலைப்பட்டியல், விலை நிர்ணயம் மற்றும் திட்டமிடல் டெம்ப்ளேட்கள்.',
    description:
      'Everything you need to start selling with clarity: a one-page business plan, pricing calculator, invoice and quotation templates, and a simple sales tracker that works in Excel or Google Sheets.',
    descriptionTa:
      'தெளிவுடன் விற்பனையைத் தொடங்க தேவையானவை: ஒரு பக்க வணிகத் திட்டம், விலைக் கணிப்பான், விலைப்பட்டியல் மற்றும் மேற்கோள் டெம்ப்ளேட்கள், மற்றும் Excel / Google Sheets-இல் இயங்கும் விற்பனைக் கண்காணிப்பு.',
    includes: ['One-page business plan', 'Invoice & quotation templates', 'Pricing calculator'],
    includesTa: ['ஒரு பக்க வணிகத் திட்டம்', 'விலைப்பட்டியல் & மேற்கோள் டெம்ப்ளேட்கள்', 'விலைக் கணிப்பான்'],
    pages: 18,
    price: 349,
  },
  {
    id: 5,
    slug: 'excel-for-beginners',
    category: 'skills',
    format: 'guide',
    language: 'both',
    coverWord: 'EXCEL',
    name: 'Excel for Beginners',
    nameTa: 'தொடக்கநிலையாளர்களுக்கான Excel',
    shortDescription:
      'Spreadsheets, simple formulas, shortcuts and practical examples.',
    shortDescriptionTa:
      'ஸ்ப்ரெட்ஷீட்கள், எளிய சூத்திரங்கள், குறுக்குவழிகள் மற்றும் நடைமுறை உதாரணங்கள்.',
    description:
      'Go from blank sheet to confident user. Learn formatting, SUM, IF and VLOOKUP, charts, filters and the keyboard shortcuts that save hours — with practice files for every chapter.',
    descriptionTa:
      'வெற்றுத் தாளிலிருந்து நம்பிக்கையான பயனராக மாறுங்கள். வடிவமைப்பு, SUM, IF, VLOOKUP, விளக்கப்படங்கள், வடிகட்டிகள் மற்றும் நேரத்தைச் சேமிக்கும் குறுக்குவழிகள் — ஒவ்வொரு அத்தியாயத்திற்கும் பயிற்சிக் கோப்புகளுடன்.',
    includes: ['12 illustrated chapters', 'Practice workbook', 'Shortcut cheat sheet'],
    includesTa: ['12 விளக்கப்பட அத்தியாயங்கள்', 'பயிற்சிப் புத்தகம்', 'குறுக்குவழிக் குறிப்புத் தாள்'],
    pages: 96,
    price: 299,
    featured: true,
  },
  {
    id: 6,
    slug: 'ai-tools-everyday-work',
    category: 'skills',
    format: 'ebook',
    language: 'en',
    coverWord: 'AI',
    name: 'AI Tools for Everyday Work',
    nameTa: 'அன்றாட வேலைக்கான AI கருவிகள்',
    shortDescription:
      'Use AI assistants to write, plan and research faster — safely and clearly.',
    shortDescriptionTa:
      'AI உதவியாளர்களைப் பயன்படுத்தி வேகமாக எழுத, திட்டமிட, ஆராய — பாதுகாப்பாகவும் தெளிவாகவும்.',
    description:
      'A practical introduction to AI assistants for students and professionals. Learn how to write good prompts, check answers, draft emails and reports, and use AI responsibly at work and school.',
    descriptionTa:
      'மாணவர்கள் மற்றும் பணியாளர்களுக்கான AI உதவியாளர்கள் பற்றிய நடைமுறை அறிமுகம். நல்ல கேள்விகளை எழுதுவது, பதில்களைச் சரிபார்ப்பது, மின்னஞ்சல் மற்றும் அறிக்கைகளை வரைவது, பொறுப்புடன் பயன்படுத்துவது.',
    includes: ['100 ready-to-use prompts', 'Fact-checking checklist', 'Workflow examples'],
    includesTa: ['100 பயன்படுத்தத் தயாரான கேள்விகள்', 'உண்மைச் சரிபார்ப்புப் பட்டியல்', 'பணிமுறை உதாரணங்கள்'],
    pages: 74,
    price: 279,
  },
  {
    id: 7,
    slug: 'build-better-habits',
    category: 'growth',
    format: 'ebook',
    language: 'both',
    coverWord: 'GROW',
    name: 'Build Better Habits',
    nameTa: 'சிறந்த பழக்கங்களை உருவாக்குங்கள்',
    shortDescription:
      'Practical ideas to organise your day and make steady progress.',
    shortDescriptionTa:
      'உங்கள் நாளை ஒழுங்கமைத்து நிலையான முன்னேற்றம் பெற நடைமுறை யோசனைகள்.',
    description:
      'Small changes, lasting results. Understand how habits form, design a morning routine that sticks, beat procrastination and track your progress with simple weekly reviews.',
    descriptionTa:
      'சிறிய மாற்றங்கள், நீடித்த பலன்கள். பழக்கங்கள் எப்படி உருவாகின்றன, நிலைக்கும் காலை வழக்கத்தை அமைப்பது, தள்ளிப்போடுதலை வெல்வது மற்றும் வாராந்திர மதிப்பாய்வுகள் மூலம் முன்னேற்றத்தைக் கண்காணிப்பது.',
    includes: ['21-day habit tracker', 'Morning routine planner', 'Weekly review pages'],
    includesTa: ['21 நாள் பழக்கக் கண்காணிப்பு', 'காலை வழக்கத் திட்டமிடல்', 'வாராந்திர மதிப்பாய்வுப் பக்கங்கள்'],
    pages: 64,
    price: 199,
    featured: true,
  },
  {
    id: 8,
    slug: 'daily-planner-journal',
    category: 'growth',
    format: 'template',
    language: 'both',
    coverWord: 'PLANNER',
    name: 'Daily Planner & Journal',
    nameTa: 'தினசரி திட்டமிடல் & நாட்குறிப்பு',
    shortDescription:
      'A printable and tablet-friendly planner for calm, focused days.',
    shortDescriptionTa:
      'அமைதியான, கவனமான நாட்களுக்கான அச்சிடக்கூடிய மற்றும் டேப்லெட்டுக்கு ஏற்ற திட்டமிடல்.',
    description:
      'An elegant undated planner with daily, weekly and monthly pages, gratitude prompts and goal-setting worksheets. Print it at home or use it on a tablet with any PDF annotation app.',
    descriptionTa:
      'தினசரி, வாராந்திர, மாதாந்திர பக்கங்கள், நன்றிக் குறிப்புகள் மற்றும் இலக்கு நிர்ணயத் தாள்களுடன் கூடிய நேர்த்தியான திட்டமிடல். வீட்டில் அச்சிடலாம் அல்லது டேப்லெட்டில் PDF செயலியுடன் பயன்படுத்தலாம்.',
    includes: ['Daily, weekly & monthly pages', 'Goal-setting worksheets', 'Printable + tablet PDF'],
    includesTa: ['தினசரி, வாராந்திர & மாதாந்திர பக்கங்கள்', 'இலக்கு நிர்ணயத் தாள்கள்', 'அச்சு + டேப்லெட் PDF'],
    pages: 120,
    price: 149,
  },
]

export function getProduct(id: number) {
  return products.find((p) => p.id === id)
}

export function formatPrice(rupees: number) {
  return `₹${rupees.toLocaleString('en-IN')}`
}

export default products
